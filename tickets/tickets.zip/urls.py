from django.urls import path, include
from rest_framework import routers
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    TicketViewSet, CategoryViewSet, TicketLogViewSet,
    MyTokenObtainPairView, UserReadOnlyViewSet, stats,
    CommentViewSet, AttachmentViewSet
)

router = routers.DefaultRouter()
router.register(r"tickets", TicketViewSet, basename="tickets")
router.register(r"categories", CategoryViewSet, basename="categories")
router.register(r"logs", TicketLogViewSet, basename="logs")
router.register(r"users", UserReadOnlyViewSet, basename="users")
router.register(r"comments", CommentViewSet, basename="comments")
router.register(r"attachments", AttachmentViewSet, basename="attachments")

urlpatterns = [
    path("token/", MyTokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("stats/", stats, name="stats"),
    path("", include(router.urls)),
]
