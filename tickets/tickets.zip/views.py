from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from django.db.models import Q
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, filters, status, mixins
from rest_framework import serializers as drf_serializers
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from django.shortcuts import render

from .models import Ticket, Category, TicketLog, Comment, Attachment
from .permissions import IsRequesterOrAssignedOrAdmin
from .serializers import (
    TicketSerializer, CategorySerializer, TicketLogSerializer,
    CommentSerializer, AttachmentSerializer,
)

def in_group(user, name):
    return user.is_authenticated and user.groups.filter(name=name).exists()

# ---------- JWT ----------
class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["username"] = user.username
        token["is_staff"] = user.is_staff
        token["roles"] = list(user.groups.values_list("name", flat=True))
        return token

class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer

# ---------- API ----------
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all().order_by("name")
    serializer_class = CategorySerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class TicketViewSet(viewsets.ModelViewSet):
    queryset = Ticket.objects.select_related("requester","assigned_to","category").all().order_by("-created_at")
    serializer_class = TicketSerializer
    permission_classes = [IsRequesterOrAssignedOrAdmin]
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    search_fields = ["title","description"]
    ordering_fields = ["created_at","updated_at","priority"]
    filterset_fields = ["state","priority","category"]

    def get_queryset(self):
        qs = super().get_queryset()
        u = self.request.user
        if not u.is_authenticated:
            return qs.none()
        if u.is_staff or in_group(u,"admin") or in_group(u,"tecnico"):
            return qs
        return qs.filter(Q(requester=u) | Q(assigned_to=u)).distinct()

    def perform_create(self, serializer):
        serializer.save(requester=self.request.user)

    @action(detail=True, methods=["post"], permission_classes=[permissions.IsAuthenticated])
    def assign(self, request, pk=None):
        if not (request.user.is_staff or in_group(request.user,"admin") or in_group(request.user,"tecnico")):
            return Response({"detail":"Forbidden"}, status=status.HTTP_403_FORBIDDEN)
        ticket = self.get_object()
        user_id = request.data.get("user_id")
        try:
            user = User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return Response({"error":"User not found"}, status=status.HTTP_404_NOT_FOUND)
        ticket.assigned_to = user
        ticket.save()
        TicketLog.objects.create(ticket=ticket, user=request.user, action="reassigned",
                                 meta_json={"to": user.id, "username": user.username})
        return Response({"status":"assigned","assigned_to":user.username})

class CommentViewSet(mixins.CreateModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = Comment.objects.select_related("ticket","user").all().order_by("-created_at")
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticated, IsRequesterOrAssignedOrAdmin]

    def get_queryset(self):
        qs = super().get_queryset()
        u = self.request.user
        if u.is_staff or in_group(u,"admin") or in_group(u,"tecnico"):
            return qs
        return qs.filter(Q(ticket__requester=u) | Q(ticket__assigned_to=u)).distinct()

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class AttachmentViewSet(mixins.CreateModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = Attachment.objects.select_related("ticket","user").all().order_by("-created_at")
    serializer_class = AttachmentSerializer
    permission_classes = [permissions.IsAuthenticated, IsRequesterOrAssignedOrAdmin]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_queryset(self):
        qs = super().get_queryset()
        u = self.request.user
        if u.is_staff or in_group(u,"admin") or in_group(u,"tecnico"):
            return qs
        return qs.filter(Q(ticket__requester=u) | Q(ticket__assigned_to=u)).distinct()

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class TicketLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = TicketLog.objects.select_related("user","ticket").all().order_by("-created_at")
    serializer_class = TicketLogSerializer
    permission_classes = [permissions.IsAuthenticated]

UserModel = get_user_model()

class UserReadOnlyViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = UserModel.objects.order_by("username")
    serializer_class = drf_serializers.Serializer
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request, *args, **kwargs):
        qs = self.get_queryset()
        u = request.user
        if not (u.is_staff or in_group(u,"admin") or in_group(u,"tecnico")):
            qs = qs.filter(pk=u.pk)
        data = [{"id": usr.id, "username": usr.username} for usr in qs]
        return Response(data)

@api_view(["GET"])
@permission_classes([permissions.IsAuthenticated])
def stats(request):
    u = request.user
    qs = Ticket.objects.all() if (u.is_staff or in_group(u,"admin") or in_group(u,"tecnico")) else \
         Ticket.objects.filter(Q(requester=u) | Q(assigned_to=u))
    return Response({
        "open": qs.filter(state="open").count(),
        "in_progress": qs.filter(state="in_progress").count(),
        "resolved": qs.filter(state="resolved").count(),
        "closed": qs.filter(state="closed").count(),
    })

# ---------- Vistas HTML (shell JWT) ----------
def home(request):
    return render(request, "index.html")

def login_page(request):
    return render(request, "login.html")

def tickets_list(request):
    return render(request, "tickets_list.html")

def ticket_new(request):
    return render(request, "ticket_new.html")

def ticket_detail(request, pk: int):
    return render(request, "ticket_detail.html", {"ticket_id": pk})
