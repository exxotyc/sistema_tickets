from django.contrib import admin
from .models import Ticket, Category, Comment, Attachment, TicketLog

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("id","title","state","priority","requester","assigned_to","updated_at")
    list_filter = ("state","priority","category","assigned_to")
    search_fields = ("title","description")

admin.site.register([Category, Comment, Attachment, TicketLog])
