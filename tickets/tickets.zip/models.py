from django.db import models
from django.contrib.auth.models import User

PRIORITY_CHOICES = [
    ("low","Baja"),
    ("medium","Media"),
    ("high","Alta"),
    ("critical","Crítica"),
]

STATE_CHOICES = [
    ("open","Abierto"),
    ("in_progress","En progreso"),
    ("resolved","Resuelto"),
    ("closed","Cerrado"),
]

class Category(models.Model):
    name = models.CharField(max_length=50, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Ticket(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    requester = models.ForeignKey(User, related_name="tickets", on_delete=models.CASCADE)
    assigned_to = models.ForeignKey(User, related_name="assigned_tickets", null=True, blank=True, on_delete=models.SET_NULL)
    category = models.ForeignKey(Category, null=True, blank=True, on_delete=models.SET_NULL)
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default="medium")
    state = models.CharField(max_length=20, choices=STATE_CHOICES, default="open")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    attachment = models.FileField(upload_to="attachments/%Y/%m/", null=True, blank=True)  # <- así


    def __str__(self):
        return f"#{self.id} {self.title}"

class TicketLog(models.Model):
    ticket = models.ForeignKey(Ticket, related_name="logs", on_delete=models.CASCADE)
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=200)
    meta_json = models.JSONField(default=dict, blank=True)   # <- DEBE existir
    created_at = models.DateTimeField(auto_now_add=True)

class Comment(models.Model):
    ticket = models.ForeignKey(Ticket, related_name="comments", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return f"Comment {self.id} on Ticket {self.ticket_id}"

class Attachment(models.Model):
    ticket = models.ForeignKey(Ticket, related_name="attachments", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    file = models.FileField(upload_to="attachments/%Y/%m/")
    mime = models.CharField(max_length=100, blank=True)
    size_bytes = models.BigIntegerField(null=True, blank=True)
    sha256 = models.CharField(max_length=64, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return f"Attachment {self.id} for Ticket {self.ticket_id}"


