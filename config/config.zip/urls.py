from django.contrib import admin
from django.urls import path, include
from tickets.views import home, login_page, tickets_list, ticket_new, ticket_detail

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", home, name="home"),
    path("login/", login_page, name="login_page"),
    path("tickets/", tickets_list, name="tickets_list"),
    path("tickets/new/", ticket_new, name="ticket_new"),
    path("tickets/<int:pk>/", ticket_detail, name="ticket_detail"),
    path("api/", include("tickets.urls")),
]
